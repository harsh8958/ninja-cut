var PLAY=1;
var END=0; 
var gameState=1;
var fruits;
var enemy;
var sword;
var monstor;

function preload(){
 swordImage=loadImage("sword.png"); 
 fruit1=loadImage("fruit1.png")
  fruit2=loadImage("fruit2.png")
  fruit3=loadImage("fruit3.png")
  fruit4=loadImage("fruit4.png")
  monstorImage=loadAnimation("alien1.png","alien2.png")
  gameOverImage=loadImage("gameover.png")
}
function setup(){
  createCanvas(600,600)
  background("white")
  
  sword=createSprite(40,200,20,20);
  sword.addImage(swordImage);
  sword.scale=0.7
  
  score=0;
  fruitGroup=createGroup();
  enemyGroup=createGroup();
}

function draw(){
  background('lightblue');
  text("Score: "+ score,500,50);
  
  if(gameState===PLAY){ 
  if(fruitGroup.isTouching(sword)){
    fruitGroup.destroyEach();
    score=score+2
  }
    if(enemyGroup.isTouching(sword))
          gameState=END;
  }
  
  else if(gameState===END){ 
    
     fruitGroup.setVelocityXEach(0)
    enemyGroup.setVelocityXEach(0)
  
  fruitGroup.setLifetimeEach(-1)
    enemyGroup.setLifetimeEach(-1)
    sword.addImage(gameOverImage);
    sword.x=200
    sword.y=200
    fruitGroup.destroyEach();
    enemyGroup.destroyEach();
  }
  
  
  sword.y=World.mouseY;
  sword.x=World.mouseX;
  
  
  
fruits();
enemy();
  
  drawSprites();
}

function fruits(){
  if(World.frameCount%60===0){
    fruit=createSprite(400,200,20,20);
    fruit.scale=0.2;
    r=Math.round(random(1,4));
    if(r==1){
      fruit.addImage(fruit1);
    }
    else if(r==2){
      fruit.addImage(fruit2);
    }
    else if(r==3){
      fruit.addImage(fruit3);
    }
    else{ 
      fruit.addImage(fruit4);
    }
    fruit.y=Math.round(random(50,500));
    
    fruit.velocityX=-10;
    fruit.setLifetime=100;
    
    fruitGroup.add(fruit);
  }
}

function enemy(){
  if(World.frameCount%200===0){
   monstor=createSprite(400,200,20,20);
    monstor.addAnimation("moving",monstorImage);
    monstor.y=Math.round(random(100,500));
    monstor.velocityX=-8;
    monstor.setLifetime=50;
    //monstor.scale=0.7;
    enemyGroup.add(monstor);
  }
}